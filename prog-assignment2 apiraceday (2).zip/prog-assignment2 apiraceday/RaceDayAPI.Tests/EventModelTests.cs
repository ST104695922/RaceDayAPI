﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using RaceDayAPI.Models;
using Xunit;

namespace RaceDayAPI.Tests
{
    public class EventModelTests
    {
        [Fact]
        public void Event_WithValidDetails_PassesValidation()
        {
            var item = new Event
            {
                EventName = "City 10K",
                EventDate = new System.DateTime(2027, 5, 1),
                Location = "Johannesburg",
                Description = "Annual road race",
                DistanceKm = 10m,
                EventType = "Road Race",
                Status = "Upcoming"
            };

            var results = new List<ValidationResult>();
            var valid = Validator.TryValidateObject(item, new ValidationContext(item), results, true);
            Assert.True(valid);
        }

        [Fact]
        public void Event_WithNonPositiveDistance_FailsValidation()
        {
            var item = new Event
            {
                EventName = "City 10K",
                EventDate = new System.DateTime(2027, 5, 1),
                Location = "Johannesburg",
                DistanceKm = 0m,
                EventType = "Road Race",
                Status = "Upcoming"
            };

            var results = new List<ValidationResult>();
            var valid = Validator.TryValidateObject(item, new ValidationContext(item), results, true);
            Assert.False(valid);
        }
    }
}
