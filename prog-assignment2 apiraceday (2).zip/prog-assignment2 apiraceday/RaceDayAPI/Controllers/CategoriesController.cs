﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.Models;
using RaceDayAPI.Security;

namespace RaceDayAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [SessionAuthorize]
    public class CategoriesController : ControllerBase
    {
        private readonly RaceDayContext _context;

        public CategoriesController(RaceDayContext context)
        {
            _context = context;
        }

        // GET: api/Categories
        // Any authenticated Participant or Organiser can view categories.
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var categories = await _context.Categories
                .AsNoTracking()
                .ToListAsync();

            return Ok(categories);
        }

        // GET: api/Categories/C0001
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            var category = await _context.Categories
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.CategoryId == id);

            if (category == null)
                return NotFound(new { message = "Category not found." });

            return Ok(category);
        }

        // POST: api/Categories
        // Organisers can create categories only for their own events.
        [HttpPost]
        [SessionAuthorize("Organiser")]
        public async Task<IActionResult> Create([FromBody] Category request)
        {
            if (request == null ||
                string.IsNullOrWhiteSpace(request.EventId) ||
                string.IsNullOrWhiteSpace(request.CategoryName))
            {
                return BadRequest(new
                {
                    message = "Event ID and category name are required."
                });
            }

            var name = request.CategoryName.Trim();
            if (name.Length > 50)
                return BadRequest(new { message = "Category name cannot exceed 50 characters." });

            if (request.DistanceKm <= 0 || request.DistanceKm > 999.99m ||
                request.EntryFee < 0 || request.EntryFee > 999999.99m)
            {
                return BadRequest(new
                {
                    message = "Distance must be positive and the entry fee cannot be negative or exceed the database limit."
                });
            }

            var organiserId = HttpContext.Session.GetString("UserId");
            var eventItem = await _context.Events
                .AsNoTracking()
                .FirstOrDefaultAsync(e => e.EventId == request.EventId);

            if (eventItem == null)
                return NotFound(new { message = "Event not found." });

            if (!string.Equals(eventItem.OrganiserId, organiserId, StringComparison.OrdinalIgnoreCase))
                return Forbid();

            var ids = await _context.Categories
                .Select(c => c.CategoryId)
                .ToListAsync();

            var highest = ids
                .Where(id => id.Length == 5 && id.StartsWith("C", StringComparison.OrdinalIgnoreCase)
                    && int.TryParse(id.Substring(1), out _))
                .Select(id => int.Parse(id.Substring(1)))
                .DefaultIfEmpty(0)
                .Max();

            if (highest >= 9999)
                return Conflict(new { message = "No more category IDs are available." });

            var category = new Category
            {
                CategoryId = $"C{highest + 1:D4}",
                EventId = eventItem.EventId,
                CategoryName = name,
                DistanceKm = request.DistanceKm,
                EntryFee = request.EntryFee
            };

            _context.Categories.Add(category);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = category.CategoryId }, category);
        }

        // PUT: api/Categories/C0001
        // Category ID and Event ID cannot be reassigned by the request body.
        [HttpPut("{id}")]
        [SessionAuthorize("Organiser")]
        public async Task<IActionResult> Update(string id, [FromBody] Category request)
        {
            if (request == null)
                return BadRequest(new { message = "A category body is required." });

            var category = await _context.Categories
                .FirstOrDefaultAsync(c => c.CategoryId == id);

            if (category == null)
                return NotFound(new { message = "Category not found." });

            var organiserId = HttpContext.Session.GetString("UserId");
            var ownsEvent = await _context.Events.AnyAsync(e =>
                e.EventId == category.EventId && e.OrganiserId == organiserId);

            if (!ownsEvent)
                return Forbid();

            var name = request.CategoryName?.Trim();
            if (string.IsNullOrWhiteSpace(name) || name.Length > 50 ||
                request.DistanceKm <= 0 || request.DistanceKm > 999.99m ||
                request.EntryFee < 0 || request.EntryFee > 999999.99m)
            {
                return BadRequest(new
                {
                    message = "Category name, distance, or entry fee is invalid."
                });
            }

            category.CategoryName = name;
            category.DistanceKm = request.DistanceKm;
            category.EntryFee = request.EntryFee;

            await _context.SaveChangesAsync();
            return Ok(category);
        }

        // DELETE: api/Categories/C0001
        // Do not delete categories referenced by enrolments.
        [HttpDelete("{id}")]
        [SessionAuthorize("Organiser")]
        public async Task<IActionResult> Delete(string id)
        {
            var category = await _context.Categories
                .FirstOrDefaultAsync(c => c.CategoryId == id);

            if (category == null)
                return NotFound(new { message = "Category not found." });

            var organiserId = HttpContext.Session.GetString("UserId");
            var ownsEvent = await _context.Events.AnyAsync(e =>
                e.EventId == category.EventId && e.OrganiserId == organiserId);

            if (!ownsEvent)
                return Forbid();

            var hasEnrolments = await _context.Enrolments
                .AnyAsync(e => e.CategoryId == id);

            if (hasEnrolments)
                return Conflict(new
                {
                    message = "Cannot delete a category while enrolments reference it."
                });

            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
