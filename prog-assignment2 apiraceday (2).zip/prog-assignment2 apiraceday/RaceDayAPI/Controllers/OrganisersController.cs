﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.Security;

namespace RaceDayAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [SessionAuthorize("Organiser")]
    public class OrganisersController : ControllerBase
    {
        private readonly RaceDayContext _context;

        public OrganisersController(RaceDayContext context)
        {
            _context = context;
        }

        // GET: api/Organisers/O0001
        // An Organiser may retrieve only their own account.
        // Account registration is handled by AuthController.
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            var sessionUserId = HttpContext.Session.GetString("UserId");

            if (string.IsNullOrWhiteSpace(sessionUserId))
                return Unauthorized(new { message = "Please log in first." });

            if (!string.Equals(id, sessionUserId, StringComparison.OrdinalIgnoreCase))
                return Forbid();

            var organiser = await _context.Organisers
                .AsNoTracking()
                .Where(o => o.OrganiserId == sessionUserId)
                .Select(o => new
                {
                    o.OrganiserId,
                    o.FullName,
                    o.Email,
                    Role = "Organiser"
                })
                .SingleOrDefaultAsync();

            if (organiser == null)
                return NotFound(new { message = "Organiser not found." });

            return Ok(organiser);
        }
    }
}
