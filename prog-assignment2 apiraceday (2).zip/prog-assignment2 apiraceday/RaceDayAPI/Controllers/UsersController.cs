﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.Security;

namespace RaceDayAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [SessionAuthorize("Participant")]
    public class UsersController : ControllerBase
    {
        private readonly RaceDayContext _context;

        public UsersController(RaceDayContext context)
        {
            _context = context;
        }

        // GET: api/Users/U0001
        // A Participant may retrieve only their own account.
        // Registration, login and profile updates are handled elsewhere.
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            var sessionUserId = HttpContext.Session.GetString("UserId");

            if (string.IsNullOrWhiteSpace(sessionUserId))
                return Unauthorized(new { message = "Please log in first." });

            if (!string.Equals(id, sessionUserId, StringComparison.OrdinalIgnoreCase))
                return Forbid();

            var user = await _context.Users
                .AsNoTracking()
                .Where(u => u.UserId == sessionUserId)
                .Select(u => new
                {
                    u.UserId,
                    u.FullName,
                    u.Email,
                    u.Role
                })
                .SingleOrDefaultAsync();

            if (user == null)
                return NotFound(new { message = "User not found." });

            return Ok(user);
        }
    }
}
