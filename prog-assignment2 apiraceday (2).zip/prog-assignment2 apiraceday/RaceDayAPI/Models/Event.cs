﻿using System.ComponentModel.DataAnnotations;

namespace RaceDayAPI.Models
{
    public class Event
    {
        public string EventId { get; set; } = string.Empty;

        [Required, StringLength(100, MinimumLength = 2)]
        public string EventName { get; set; } = string.Empty;

        [Required]
        public DateTime EventDate { get; set; }

        [Required, StringLength(100, MinimumLength = 2)]
        public string Location { get; set; } = string.Empty;

        [StringLength(500)]
        public string? Description { get; set; }

        [Range(typeof(decimal), "0.01", "9999.99")]
        public decimal? DistanceKm { get; set; }

        [Required, StringLength(50, MinimumLength = 2)]
        public string EventType { get; set; } = "Road Race";

        [Required, StringLength(20)]
        public string Status { get; set; } = "Upcoming";

        public string OrganiserId { get; set; } = string.Empty;
    }
}
